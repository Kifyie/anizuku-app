@file:Suppress("ktlint:standard:property-naming")

package eu.kanade.tachiyomi.source.model

import kotlinx.serialization.json.JsonObject
import suwayomi.tachidesk.manga.impl.util.lang.EMPTY

class SMangaImpl : SManga {
    override lateinit var url: String

    override lateinit var title: String

    override var thumbnail_url: String? = null

    override var artist: String? = null

    override var author: String? = null

    override var status: Int = 0

    override var description: String? = null

    override var genre: String? = null

    override var update_strategy: UpdateStrategy = UpdateStrategy.ALWAYS_UPDATE

    override var initialized: Boolean = false

    override var memo: JsonObject = JsonObject.EMPTY
}
